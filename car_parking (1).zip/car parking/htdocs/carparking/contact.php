<?php include 'main.php';?>
<!DOCTYPE HTML>
<html>
<head>
<link rel="stylesheet" type="text/css" href="inc/css/structure.css">
<link rel="stylesheet" type="text/css" href="inc/css/mystyles.css">
</head>
<body>
<section class="HomeKisii">
<p>We are at your service. Call our support team any time as from 7.00am - 10.00pm</p>
<P> Call +254729667794 or +254715160551 </p>
<p> or e-mails us :ibrahimond75@yahoo.com or kisiicounty.go.ke</p>
</section>
<section class="kisii-bottom">
<p>Safe Parking, whenever you are in Kisii</p>
</section>
</body>
</html>
