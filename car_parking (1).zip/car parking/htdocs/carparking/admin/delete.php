<?php
$id=$_POST['submit_multi'];


?>