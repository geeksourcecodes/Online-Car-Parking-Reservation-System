
<?php include 'main.php';?>
<!DOCTYPE HTML>
<html>
<head>
<link rel="stylesheet" type="text/css" href="inc/css/structure.css">
</head>

<form class="box login" action="parking_space.php" method="post">

	<fieldset class="boxBody">
	<hr />
	<label><strong>You are not logged in!</strong></label>
	<hr />
	</fieldset>
	<footer>
	  <input type="submit" class="btnLogin" value="Proceed" tabindex="4">
	</footer>
</form>
</html>
